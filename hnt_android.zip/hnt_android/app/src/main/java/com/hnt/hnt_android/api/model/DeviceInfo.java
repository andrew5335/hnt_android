package com.hnt.hnt_android.api.model;

public class DeviceInfo {
}
